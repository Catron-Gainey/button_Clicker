function logoff(element) {
    element.innerText = "logoff";
}
function hide(element) {
    element.remove();
}